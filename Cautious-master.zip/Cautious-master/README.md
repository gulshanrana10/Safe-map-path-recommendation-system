<h1> Hack Infinity 2.0  </h1>
<h2> <b> CAUTIOUS </b> </h2>
<h3> Introduction </h3>

This app was designed to make you not only feel safe but also assist you in any dangerous situation.It could help minimize any catastrophic event to take place by not only letting the near police patrol know about the status of the distress but also shares the safest route which should be followed.
In case of any distress, it shares the your current location with the police as well as the local guardian.

<h3> Motivation </h3>

Looking at the current world scenario we wanted to make an impact which would not only reduce the safety issue cases at national level but also at the global level.<br> 
We were really disgust by the current cases in India like Unnao and Nirbhaya. It feels really terible to be living in that kind of society, so rather than putting blame on others and empathizing for victims, we decided to come up with <b>Cautious</b> - An app that helps you take care of your safety. <br> 
We want to prune each and every case so that there is no future victim.

<h3>Usage and Running the application</h3>
To use the application 
on Android: Download the apk named app-release.apk provided in the repository and install it
Webpage : www.cautious.herokuapp.com

<h3> Tech-Stack </h3>
<ul>
  <li> HTML, CSS, Bootstrap </li>
  <li> JavaScript </li>
  <li> Firebase </li>
  <li> Heroku - for deployment purposes </li>
  <li> MapBox API </li>
  <li> Flutter </li>
  <li> Progressive Web Apps (PWA) </li>
 </ul>


<h3> Future Scalibility </h3>

We are looking forward to notify the respective patroling and police helps or be it medical without making any of our user actually performing any dedicated action. With the use of accelerometer and gyroscope in mobile, we would be aiming to utilize that data and study the abnormality of the motion of the phone, also we'll be utilising the speed using google api, if it is exceeding the speed limit of that particular area, which either means there is some kind of crime being commited or that person is breaking the law by overspeeding, either way immediate police attention is required. 
