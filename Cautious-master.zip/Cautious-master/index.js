const reDirectTo = () => {
    location.href = 'app.php';
}

const backToMain = () => {
    location.href = 'main.php';
}